import java.*;
import java.io.*;
import java.util.Scanner;
import org.apache.commons.io.FileUtils;
import org.json.JSONObject;
import org.json.JSONArray;


public class App {
  public static void main(String[] args)  throws Exception {
    //Scanner sc = new Scanner(System.in);
    //System.out.println("Ingrese el ID del doctor: ");
    //int IdDoctor = sc.nextInt();
    /**** LECTURA DE FUNCIONARIOS ****/
    /*Se lee el archivo json de los funcionarios del hospital para luego parsear
    el json con los metodos de la libreria usada. En primer lugar el json en
    convertido en un objeto json, luego cada tiop array de cada funcionario es convertido
    en un Jsonarray para volver a parsearlo y poder crear una lista del tipo correspondiente
    a cada tipo de funcionario */
    File file = new File("/home/fran/Escritorio/Distribuidos/Tarea3/Tarea-3-Sistemas-Distribuidos/Doctores/src/main/java/funcionarios.json");
    String content = FileUtils.readFileToString(file, "utf-8");
    // Convert JSON string to JSONObject
    JSONObject funcionariosJsonObject = new JSONObject(content);
    //Json array: obtener doctores, enfermeros y paramedicos desde el JSON
    JSONArray doc = funcionariosJsonObject.getJSONArray("Doctor");
    JSONArray enf = funcionariosJsonObject.getJSONArray("enfermero");
    JSONArray par = funcionariosJsonObject.getJSONArray("Paramedico");

    /*
    //Instancia de cada tipo de funcionario
    Doctor dr;
    enfermero enfermero;
    paramedico parmedico;
    //Listas para cada tipo de funcionarios
    List<Doctor> doctores = new ArrayList<Doctor>();
    List<enfermero> enfermeros = new ArrayList<enfermero>();
    List<paramedico> paramedicos = new ArrayList<paramedico>();
    */

    //JSONObject obtener datos de cada doctor
    for (int i = 0; i < doc.length(); i++) {
      JSONObject nDoctor = doc.getJSONObject(i);
      /*d = new Doctor(nDoctor.getInt("id"),
                     nDoctor.getString("nombre"),
                     nDoctor.getString("apellido"),
                     nDoctor.getInt("estudios"),
                     nDoctor.getInt("experiencia"));
      doctores.add(d);*/
    }
    for (int i = 0; i < enf.length(); i++) {
      JSONObject nEnfermero = enf.getJSONObject(i);
      /*d = new Doctor(nEnfermero.getInt("id"),
                     nEnfermero.getString("nombre"),
                     nEnfermero.getString("apellido"),
                     nEnfermero.getInt("estudios"),
                     nEnfermero.getInt("experiencia"));
      enfermeros.add(d);*/
    }
    for (int i = 0; i < par.length(); i++) {
      JSONObject nParamedico = par.getJSONObject(i);
      /*d = new Doctor(nParamedico.getInt("id"),
                     nParamedico.getString("nombre"),
                     nParamedico.getString("apellido"),
                     nParamedico.getInt("estudios"),
                     nParamedico.getInt("experiencia"));
      paramedicos.add(d);*/
    }
    /**** LECTURA DE PACIENTES ****/
    /*El mismo procedimiento explicado anteriormente*/
    File file2 = new File("/home/fran/Escritorio/Distribuidos/Tarea3/Tarea-3-Sistemas-Distribuidos/data/pacientes.json");
    String content2 = FileUtils.readFileToString(file2, "utf-8");
    //Extraer arreglo de pacientes
    JSONArray pacientesJsonArray = new JSONArray(content2);
    List<paciente> pacientes = new ArrayList<paciente>();
    //Extraer pacientes
    for(int i=0; i < pacientesJsonArray.length(); i++){
      JSONObject d;
      List<String> enfermedades = new ArrayList<String>();
      List<String> procesoA = new ArrayList<String>();
      List<String> procesoC = new ArrayList<String>();
      List<String> examenR = new ArrayList<String>();
      List<String> examenNR = new ArrayList<String>();
      List<String> medR = new ArrayList<String>();
      List<String> medS = new ArrayList<String>();
      JSONObject paciente = pacientesJsonArray.getJSONObject(i);
      //Extraer datos del paciente
      JSONArray datos = paciente.getJSONArray("datos personales");
      for(int j=0; j<datos.length(); j++){
        d = datos.getJSONObject(j);
      }
      //Extraer enfermedades del paciente
      JSONArray enfermedades = paciente.getJSONArray("enfermedades");
      for(int j=0; j<enfermedades.length(); j++){
        enfermedades.add(enfermedades.get(j));
      }
      //Extraer tratamientos del paciente
      JSONArray tratamientos = paciente.getJSONArray("tratamientos/procedimientos");
      for(int j=0; j<tratamientos.length(); j++){
        JSONObject t = tratamientos.getJSONObject(j);
        //Extraer tratamientos asignados
        JSONArray asignados = t.getJSONArray("asignados");
        for(int k=0; k<asignados.length(); k++){
          procesoA.add(asignados.get(k));
        }
        //Extraer tratamientos completados
        JSONArray completados = t.getJSONArray("completados");
        for(int k=0; k<completados.length(); k++){
          procesoC.add(completados.get(k));
        }
      }
      //Extraer examenes
      JSONArray examenes = paciente.getJSONArray("examenes");
      for(int j=0; j<examenes.length(); j++){
        JSONObject e = examenes.getJSONObject(j);
        //Extraer examenes realizados
        JSONArray realizados = e.getJSONArray("realizados");
        for(int k=0; k<realizados.length(); k++){
          examenR.add(realizados.get(k));
        }
        //Extraer examenes no realizados
        JSONArray NRealizados = e.getJSONArray("no realizados");
        for(int k=0; k<NRealizados.length(); k++){
          examenNR.add(NRealizados.get(k));
        }
      }
      //Extraer medicamentos
      JSONArray medicamentos = paciente.getJSONArray("medicamentos");
      for(int j=0; j<medicamentos.length(); j++){
        JSONObject m = medicamentos.getJSONObject(j);
        //Extraer medicamentos recetados
        JSONArray recetados = m.getJSONArray("recetados");
        for(int k=0; k<recetados.length(); k++){
          medR.add(recetados.get(k));
        }
        //Extraer examenes suministrados
        JSONArray suministrados = m.getJSONArray("suministrados");
        for(int k=0; k<suministrados.length(); k++){
          medS.add(suministrados.get(k));
        }
      }
      /*pte = new paciente(paciente.getInt("paciente_id"),
                         d.getString("nombre"),
                         d.getString("rut"),
                         d.getString("edad"),
                         enfermedades,
                         procesoA,
                         procesoC,
                         examenR,
                         examenNR,
                         medR,
                         medS);
      pacientes.add(pte);*/
    }
    /**** LECTURA DE REQUERIMIENTOS ****/
    /*El mismo procedimiento explicado anteriormente*/
    File file3 = new File("/home/fran/Escritorio/Distribuidos/Tarea3/Tarea-3-Sistemas-Distribuidos/Doctores/src/main/java/requerimientos.json");
    String content3 = FileUtils.readFileToString(file, "utf-8");
    // Convert JSON string to JSONObject
    JSONObject requerimientosJsonObject = new JSONObject(content3);
    JSONArray req = requerimientosJsonObject.getJSONArray("requerimientos");
    List<requerimiento> requerimientos = new ArrayList<requerimiento>();
    for (int i = 0; i < req.length(); i++) {
      HashMap<String, String> procedimientos = new HashMap<>();
      JSONObject nReq = req.getJSONObject(i);

      JSONArray pacient = nReq.getJSONArray("pacientes");
      for(int j = 0;j < nReq.lenght(); j++){
        requerimientos.put(j,nReq.getString(j));
      }
      /*r = new requerimiento(nReq.getInt("id"),
                     nReq.getString("cargo"),
                     requerimientos);
      requerimiento.add(r);*/
    }

  }
}
