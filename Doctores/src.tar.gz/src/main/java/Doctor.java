import java.util.*;

//Clase doctor
public class Doctor{
  //atributos
  public int id;
  public String nombre;
  public String apellido;
  public int estudios;
  public int experiencia;

  //Constructor
  public Doctor(int id, String nombre, String apellido, int estudios, int experiencia){
    id = id;
    nombre = nombre;
    apellido = apellido;
    estudios = estudios;
    experiencia = experiencia;
  }
}
