import java.util.*;

//Clase paramedico
public class Paramedico{
  //atributos
  public int id;
  public String nombre;
  public String apellido;
  public int estudios;
  public int experiencia;

  //Constructor
  public Paramedico(int id, String nombre, String apellido, int estudios, int experiencia){
    id = id;
    nombre = nombre;
    apellido = apellido;
    estudios = estudios;
    experiencia = experiencia;
  }
}
